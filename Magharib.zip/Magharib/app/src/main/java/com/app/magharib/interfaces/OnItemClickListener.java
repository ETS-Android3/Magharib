package com.app.magharib.interfaces;

import android.view.View;

public interface OnItemClickListener {
    void onClick(Object parent, View view, int position);
}
