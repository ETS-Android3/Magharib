package com.app.magharib.Model;

public class User {
    private String first_name ;
    private String last_name ;
    private String age ;
    private String email ;
    private String password ;
    private String account_type;
    private String is_enabled ;
    private String id_user_order ;

    public User(String first_name, String last_name, String age, String email, String password, String account_type, String is_enabled, String id_user_order) {
        this.first_name = first_name;
        this.last_name = last_name;
        this.age = age;
        this.email = email;
        this.password = password;
        this.account_type = account_type;
        this.is_enabled = is_enabled;
        this.id_user_order = id_user_order;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAccount_type() {
        return account_type;
    }

    public void setAccount_type(String account_type) {
        this.account_type = account_type;
    }

    public String getIs_enabled() {
        return is_enabled;
    }

    public void setIs_enabled(String is_enabled) {
        this.is_enabled = is_enabled;
    }

    public String getId_user_order() {
        return id_user_order;
    }

    public void setId_user_order(String id_user_order) {
        this.id_user_order = id_user_order;
    }
}
